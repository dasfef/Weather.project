function select_change(){

    $('#selector').submit();

};